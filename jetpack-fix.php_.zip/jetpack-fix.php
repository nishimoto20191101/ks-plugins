<?php
/*
Plugin Name: Facebook自動投稿不具合修正プラグイン
Plugin URI: http://proclass.jp/
Description: jetpackでfacebookと投稿自動連携した際の不具合解消のためのプラグインです。
Version: 0.1
Author: プロクラス 
Author URI: http://proclass.jp/
License: GPL2
*/

/** パブリサイズ共有の文言を変更 */
function change_jetpack_publicize_content( $post_id, $post )
{
$POST_MESS = '_wpas_mess';

/** 投稿,下書き,スケジュール待ちのみ */
if ( !in_array( $post->post_status, array( 'publish', 'future' ) ) ) {
return;
}

/** カスタムメッセージのPOSTがあったら無視 */
if ( !empty( $_POST['wpas_title'] ) ) {
return;
}

/** カスタムメッセージがある場合は無視 */
if( get_post_meta( $post_id, $POST_MESS, TRUE ) ) {
return;
}

/** 共有する文言の成形 */
$publicize_custom_message = sprintf( '新しいブログを投稿しました！『%s』%s', $post->post_title, wp_get_shortlink( $post->ID ) );

/** カスタムメッセージとして登録 */
update_post_meta( $post_id, $POST_MESS, $publicize_custom_message );

/** postmetaが削除されないように$_POSTにも代入 */
$_POST['wpas_title'] = $publicize_custom_message;
}
/** JetPackのパブリサイズ共有のsave_postに対する処理の優先度は「20」 */
add_action( 'save_post', 'change_jetpack_publicize_content', 19, 2 );
?>