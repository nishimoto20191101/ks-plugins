<?php
$exec_key = !empty($_GET["key"]) ? $_GET["key"] : "";
$mode = !empty($_GET["mode"]) ? $_GET["mode"] : "";
$result = "";

if(!empty($mode)){
    include_once( dirname(__FILE__).'/../../../../wp-load.php');
    require_once( dirname(__FILE__).'/../class.php');
    $ks_ai_nikki = new Ks_AI_nikki();
    $ks_ai_nikki->set_AI_Client();
    add_action('init', [$ks_ai_nikki, 'init']);
    if($ks_ai_nikki->get_config_key() == $exec_key){
        if( $mode == "post"){
            $no = !empty($_GET["no"]) ? $_GET["no"] : 0;
            $result = !empty($ks_ai_nikki->sched[$no]) ? $ks_ai_nikki->ks_post_sched_exec($no) : "";
            echo $result ? "「{$ks_ai_nikki->sched[$no]->nikki_title}」 実行完了しました。" : "「{$ks_ai_nikki->sched[$no]->nikki_title}({$no})」 実行失敗しました。";
            return true;
        }else if($mode == "make"){
            $item = !empty($_GET["item"]) ? $_GET["item"] : "";
            if($item == "title"){
                echo "タイトル<br>";
                echo $ks_ai_nikki->mk_title();
                return true;
            }else if($item == "anser"){
                if(!empty($_GET["message"])){
                    $text_form = !empty($_GET["text_form"]) ? $_GET["text_form"] : "日記";
                    echo "<!-- wp:html -->\n".$ks_ai_nikki->post_generation( ["title"=>$_GET["message"], "text_form"=>$text_form] )["content"]."\n<!-- /wp:html -->";
                    return true;
                }
            }else if($item == "prompt"){
                if(!empty($_GET["exp"])){
                    echo "結果".$ks_ai_nikki->mk_prompt( $_GET["exp"] );
                    return true;
                }
            }else if($item == "image"){
                if(!empty($_GET["exp"])){
                    $result = $ks_ai_nikki->ks_image_insert( $_GET["exp"] );
                    $size = !empty($_GET['size']) ? $_GET['size'] : "full"; //'thumbnail', 'medium', 'large', 'full'
                    if( !empty($result["file"])){
                        echo wp_get_attachment_image($result["file"], $size);
                    }else if(!empty($result["image"]->data)){
                        header("Content-Type: {$result["image"]->mimeType}");
                        echo base64_decode($result["image"]->data);
                    }else{
                        print_r($result);
                    }
                    return true;
                }
            }
        }else if($mode == "get"){
            $post_type = !empty($_GET["post_type"]) ? $_GET["post_type"] : "post";
            $item = !empty($_GET["item"]) ? $_GET["item"] : "post_category"; // post_category or post_tag
            $write =  !empty($_GET["write"]) ? $_GET["write"] : "html";
            $taxonomies = get_taxonomies([
                'public' => true,
                'object_type' => [ $post_type ],
            ], 'objects');
            //タクソノミーごとにターム情報の配列を格納する
            if(is_array($taxonomies)){
                foreach( $taxonomies as $tax ) {
                    $name = $tax->name;
                    $$name = get_terms( $name, ['hide_empty' => false] );
                    if(is_array($$name)){
                        //タームメタ情報を取得
                        foreach( $$name as $term_temp ) {
                            if( !empty($term_temp) ) {
                                $term_temp->term_meta = get_term_meta( $term_temp->term_id );
                                if( $item == "post_category" ? $term_temp->taxonomy != "post_tag" && $term_temp->slug != "uncategorized" : $term_temp->taxonomy == $item ){
                                    if( $write == "object" ){
                                        $result .= print_r($term_temp, true);
                                    }else{
                                        $input_name = $name == "category" ? "post_category" : $name;
                                        $result .=<<<HTML
<label><input type="checkbox" name="{$input_name}[]" value="{$term_temp->term_id}" class="{$term_temp->slug}"><span>{$term_temp->name}</span></label>
HTML;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            $write !== "object" && empty($result) && ( $result = '<span>選択可能な項目はありません。</span>' );
            echo $result;
        }else if($mode == "export"){
            $result = $ks_ai_nikki->dl_zip_data_fld();
        }else if($mode == "search"){
            if(!empty($_GET["word"])){
                echo "<h1>{$_GET["word"]}</h1>\n";
                $result = "";
                $news = $ks_ai_nikki->get_news4google($_GET["word"], 5);
                if(is_array($news)){
                    foreach( $news as $key => $val){
                        $result .= "<h3>{$val["title"]}</h3><p>{$val["url"]}</p>\n";
                    }
                }
                echo $result;
            }else{
                echo "...";
            }
        }else if($mode == "trends"){
            echo "<h1>Google Trends</h1>\n";
            $result = "<ul>";
            $trends = $ks_ai_nikki->get_trends4google();
            if(is_array($trends)){
                foreach( $trends as $key => $val){
                    $result .= "<li>{$val["title"]}</li>";
                }
            }
            $result .= "</ul>";
            echo $result."<hr>";
        }
    }
    return false;
} 
